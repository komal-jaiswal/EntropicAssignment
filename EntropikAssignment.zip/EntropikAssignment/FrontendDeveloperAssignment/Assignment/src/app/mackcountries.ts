import { Country } from './country';

export const CounteryInfo: Country[] = [
    { countryCode: 'gb', countryDesc: 'Great Britain is an island in the North Atlantic Ocean off the northwest coast of continental Europe. With an area of 209,331 km2 (80,823 sq mi), it is the largest of the British Isles, the largest European island, and the ninth-largest island in the world. In 2011, Great Britain had a population of about 61 million people, making it the world\'s third-most populous island after Java in Indonesia and Honshu in Japan.The island of Ireland is situated to the west of Great Britain, and together these islands, along with over 1,000 smaller surrounding islands, form the British Isles archipelago.' },
    { countryCode: 'au', countryDesc: 'Australia, officially the Commonwealth of Australia, is a sovereign country comprising the mainland of the Australian continent, the island of Tasmania, and numerous smaller islands. It is the largest country in Oceania and the world\'s sixth-largest country by total area.' },
    { countryCode: 'fr', countryDesc: 'France, in Western Europe, encompasses medieval cities, alpine villages and Mediterranean beaches. Paris, its capital, is famed for its fashion houses, classical art museums including the Louvre and monuments like the Eiffel Tower. The country is also renowned for its wines and sophisticated cuisine. Lascaux’s ancient cave drawings, Lyon’s Roman theater and the vast Palace of Versailles attest to its rich history.' },
    { countryCode: 'others', countryDesc: 'nothing much to say!!!' }
];
