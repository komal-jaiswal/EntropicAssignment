export class Country {
    countryCode: string;
    countryDesc: string;
}
