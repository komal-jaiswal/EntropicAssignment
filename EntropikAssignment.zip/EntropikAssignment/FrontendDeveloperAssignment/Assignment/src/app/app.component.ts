import { Component,OnInit } from '@angular/core';
import { CountryService } from './country.service';
import { Country } from './country';
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(private countryService: CountryService, private route: Router) { }
  countries: Country[];
  ngOnInit() {
    this.getCountriesInfo();
  }
  getCountriesInfo(): void {
    this.countryService.getCountries().subscribe(data => this.countries = data);
  }
  countryDetails(countryCode: string) {
    this.route.navigate(['/dashboard', countryCode]);
  }
}
