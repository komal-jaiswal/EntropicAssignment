import { Injectable } from '@angular/core';
import { Country } from './country';
import { CounteryInfo } from './mackcountries';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
export const notFound = 404;

@Injectable({
  providedIn: 'root'
})
export class CountryService {

  baseURL = 'https://randomuser.me/api/?nat='
  constructor(private http: HttpClient) { }
  getCountries(): Observable<Country[]> {
    return of(CounteryInfo);
  }
  getCountryDesc(countryCode: string): Country {
    return CounteryInfo.find(country => country.countryCode === countryCode);
  }
  getCountry(searchTerm: string): Observable<any> {
    return this.http.get(this.baseURL + searchTerm).pipe(catchError(err => of(err.status === notFound ? null : {})));
  }
}
