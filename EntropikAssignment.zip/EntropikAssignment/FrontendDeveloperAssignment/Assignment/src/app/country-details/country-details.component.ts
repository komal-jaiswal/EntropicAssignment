import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Country } from '../country';
import { CountryService } from '../country.service';

@Component({
  selector: 'app-country-details',
  templateUrl: './country-details.component.html',
  styleUrls: ['./country-details.component.css']
})
export class CountryDetailsComponent implements OnInit {
  countryCode: string;
  countryInfo: Country;
  constructor(private actRoute: ActivatedRoute, private route: Router, private countryService: CountryService) { }

  ngOnInit() {
    this.actRoute.paramMap.subscribe(params => {
      this.countryCode = params.get('countryCode');
    });
    this.getCountryInfo(this.countryCode);
  }
  getCountryInfo(countryCode: string) {
    this.countryInfo = this.countryService.getCountryDesc(countryCode);
  }
  back() {
    this.route.navigate(['/dashboard']);
  }
}
