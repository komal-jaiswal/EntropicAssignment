import { Component, OnInit,OnDestroy } from '@angular/core';
import { Country } from '../country';
import { CountryService } from '../country.service';
import { Subscription} from 'rxjs';
import { Chart } from 'chart.js';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit,OnDestroy {
  searchTerm: string;
  countrySubscription: Subscription;
  countryData: any;
  searchedCountry: string[] = [];
  currentDate: Date = new Date();
  countries: Country[];
  PieChart = [];

  constructor(private countryService: CountryService) { }

  ngOnInit() {
    this.PieChart = new Chart('pieChart', {
      type: 'pie',
      data: {
        labels: ['AU', 'GB', 'FR', 'other'],
        datasets: [{
          label: 'countries chart status',
          data: [6, 8, 6, 6],
          backgroundColor: [
            'yellow', 'purple', 'red', 'green'
          ]
        }]
      },
      options: {
        title: {
          text: 'countries',
          display: true
        },
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: true
            }
          }]
        }
      }
    },
    );
  }

  go(searchTerm: string) {
    this.searchedCountry.push(searchTerm);
    this.countrySubscription = this.countryService.getCountry(searchTerm).subscribe(data =>
      this.countryData = data);
  }

  ngOnDestroy(): void {
    this.countrySubscription && this.countrySubscription.unsubscribe();
  }
}
